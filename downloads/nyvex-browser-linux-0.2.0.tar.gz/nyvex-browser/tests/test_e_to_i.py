import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from browser.facade import NyvexBrowserApp
from gecko.runtime import GeckoRuntime

app = NyvexBrowserApp()
assert app.navigate("nyvex://settings").startswith("nyvex://")
assert app.privacy.status()["ready"]
assert app.settings.get("search_engine") == "duckduckgo"
g = GeckoRuntime()
print("gecko", g.status())
print("https", g.probe_https())
app.shutdown()
print("test_e_to_i OK")
