import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from navigation.address import normalize_input, looks_like_url
assert looks_like_url("https://a.com")
assert looks_like_url("example.com")
assert not looks_like_url("how to cook")
assert normalize_input("example.com").startswith("https://")
assert "duckduckgo.com" in normalize_input("hello world")
assert normalize_input("nyvex://home") == "nyvex://home"
print("test_address OK")
