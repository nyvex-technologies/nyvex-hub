import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from tabs.manager import TabManager
from windows.manager import WindowManager

t = TabManager()
t.new("https://a.com", "A")
t.new("https://b.com", "B")
assert len(t.tabs) == 2
assert t.current()["url"] == "https://b.com"
closed = t.close()
assert closed["url"] == "https://b.com"
assert len(t.tabs) == 1
t.pin(0)
assert t.tabs[0]["pinned"] is True

wm = WindowManager()
wm.current_tabs().new("https://x.com")
wm.new_window(private=True)
assert len(wm.windows) == 2
assert wm.current()["private"] is True
sess = wm.to_session()
assert len(sess["windows"]) == 2
print("test_tabs OK")
