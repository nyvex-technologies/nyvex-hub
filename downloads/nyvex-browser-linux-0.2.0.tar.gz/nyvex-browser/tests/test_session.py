import sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from sessions.store import SessionStore
from sessions.closed import ClosedTabs
from sessions.saved import SavedSessions

with tempfile.TemporaryDirectory() as d:
    root = Path(d)

    s = SessionStore(root, debounce_sec=0.05)
    s.load()
    assert not s.crashed()

    s.mark_dirty_start()
    assert s.crashed()  # открыта, ещё не clean shutdown

    s.set_tabs(0, [{"url": "https://a.com", "title": "A", "pinned": False}], 0)
    time.sleep(0.2)
    s.save_now()
    assert s.has_session_file()

    # имитация краша: dirty остаётся
    assert s.crashed()

    # новый запуск видит crash
    s2 = SessionStore(root, debounce_sec=0.05)
    s2.load()
    assert s2.crashed()
    assert s2.load()["windows"][0]["tabs"][0]["url"] == "https://a.com"

    s2.mark_clean_shutdown()
    assert not s2.crashed()

    c = ClosedTabs(3)
    c.push({"url": "https://x.com"})
    assert c.pop()["url"] == "https://x.com"

    saved = SavedSessions(root)
    saved.save("Dev", SessionStore(root).load())
    assert saved.list()

print("test_session OK")
