import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from navigation.address import normalize_input, looks_like_url
from navigation.omnibox import Omnibox
from search.engines import SearchEngines

assert looks_like_url("github.com")
assert not looks_like_url("how to install linux")
assert normalize_input("github.com").startswith("https://")
assert "duckduckgo.com" in normalize_input("privacy tools")
assert "google.com" in normalize_input("g open source")  # keyword g
assert "duckduckgo.com" in normalize_input("d firefox search")

se = SearchEngines("duckduckgo")
assert "duckduckgo" in se.build("test")

om = Omnibox(
    history_items=[{"url": "https://example.com", "title": "Example"}],
    bookmark_items=[{"url": "https://nyvex.local", "title": "Nyvex"}],
)
s = om.suggest("exam")
assert any(x["type"] == "history" for x in s)
print("test_search OK")
