import sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from history.store import HistoryStore
from bookmarks.store import BookmarkStore
from downloads.manager import DownloadManager
from internal_pages.registry import is_internal, resolve
from core.app_d import BrowseService

with tempfile.TemporaryDirectory() as d:
    root = Path(d)
    h = HistoryStore(root)
    h.add("https://example.com", "Example")
    h.add("https://example.com", "Example")
    assert h.search("exam")
    assert h._items[0]["visits"] == 2
    b = BookmarkStore(root)
    b.add("https://nyvex.local", "Nyvex")
    assert len(b.list_flat()) == 1
    b.remove(b.list_flat()[0]["id"])
    assert len(b.list_flat()) == 0
    dl = DownloadManager()
    item = dl.start("https://x.com/file.zip")
    dl.set_status(item["id"], "done", 1.0)
    assert dl.list()[0]["status"] == "done"

assert is_internal("nyvex://home")
assert resolve("nyvex://history") == "history"
svc = BrowseService()
assert svc.go("nyvex://home") == "nyvex://home"
print("test_storage OK")
