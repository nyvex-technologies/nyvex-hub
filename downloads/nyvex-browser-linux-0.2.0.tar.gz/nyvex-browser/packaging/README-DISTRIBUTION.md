# Nyvex Browser — распространение

## Linux (сейчас)
- Установка: `~/.local/bin/nyvex-browser` + `.desktop`
- Зависимости: python, python-gobject, gtk3, webkit2gtk
- Дальше: AppImage (python-appimage) или Flatpak

## Windows / macOS (план)
- UI на Tauri (Rust) или Electron
- Движок: системный WebView2 (Win) / WKWebView (macOS)
- Тот же UX: вкладки, Hub, темы — логика на JS или общая web-страница

## Android / iOS
- Не GTK. Варианты:
  1. PWA сайта Nyvex Hub / web-оболочки браузера
  2. Capacitor-обёртка
  3. Отдельное приложение в store

## Честно
Полноценный Gecko-форк на все ОС = годы и команда (уровень Firefox).
Сейчас продукт: Linux-браузер WebKit2 + экосистема Nyvex через Hub (PWA на телефонах).
