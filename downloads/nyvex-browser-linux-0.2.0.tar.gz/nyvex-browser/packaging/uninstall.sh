#!/bin/bash
rm -f ~/.local/bin/nyvex-browser
rm -f ~/.local/share/applications/nyvex-browser.desktop
rm -f ~/.local/share/metainfo/technologies.nyvex.browser.metainfo.xml
rm -f ~/.local/share/icons/hicolor/scalable/apps/nyvex-browser.svg
update-desktop-database ~/.local/share/applications 2>/dev/null || true
echo "Nyvex Browser удалён из меню и PATH (код в ~/nyvex-browser сохранён)."
