from __future__ import annotations
from typing import Any

class ExtensionManager:
    """26 WebExtensions — список/флаги до реального loader."""
    def __init__(self) -> None:
        self.extensions: list[dict[str, Any]] = []

    def status(self) -> dict[str, Any]:
        return {"module": "ExtensionManager", "ready": False, "note": "needs Gecko WebExtension API"}
