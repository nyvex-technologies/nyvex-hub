from __future__ import annotations
from pathlib import Path
from typing import Any

class ProfileManager:
    def __init__(self, root: Path | None = None) -> None:
        self.root = root or Path.home() / ".local/share/nyvex-browser"
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "Default").mkdir(exist_ok=True)

    def list(self) -> list[str]:
        return sorted([p.name for p in self.root.iterdir() if p.is_dir()])

    def status(self) -> dict[str, Any]:
        return {"module": "ProfileManager", "ready": True, "profiles": self.list()}
