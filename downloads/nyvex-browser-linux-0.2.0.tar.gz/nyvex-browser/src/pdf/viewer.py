from __future__ import annotations
from typing import Any
class PdfViewer:
    def status(self) -> dict[str, Any]:
        return {"module": "PdfViewer", "ready": False}
