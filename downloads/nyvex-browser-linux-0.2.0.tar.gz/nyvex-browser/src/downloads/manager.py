from __future__ import annotations
import time, uuid
from typing import Any

class DownloadManager:
    """Пункт 18 — загрузки (учёт; реальный download — после Gecko)."""
    def __init__(self) -> None:
        self.items: list[dict[str, Any]] = []

    def start(self, url: str, filename: str = "") -> dict:
        item = {
            "id": uuid.uuid4().hex[:12],
            "url": url,
            "filename": filename or url.rsplit("/", 1)[-1] or "download",
            "status": "queued",
            "progress": 0.0,
            "ts": int(time.time()),
        }
        self.items.insert(0, item)
        return item

    def set_status(self, did: str, status: str, progress: float | None = None) -> None:
        for it in self.items:
            if it["id"] == did:
                it["status"] = status
                if progress is not None:
                    it["progress"] = progress
                break

    def list(self) -> list[dict]:
        return list(self.items)

    def remove(self, did: str) -> None:
        self.items = [i for i in self.items if i["id"] != did]
