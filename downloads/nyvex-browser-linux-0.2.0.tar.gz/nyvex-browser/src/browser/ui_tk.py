from __future__ import annotations
import tkinter as tk
from tkinter import messagebox
from pathlib import Path
import sys
import json

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from navigation.address import normalize_input
from navigation.omnibox import Omnibox
from browser.engine import Engine
from sessions.store import SessionStore
from sessions.closed import ClosedTabs
from history.store import HistoryStore
from bookmarks.store import BookmarkStore
from tabs.manager import TabManager
from settings.store import SettingsStore
from internal_pages.registry import is_internal, resolve, render_stub

class NyvexWindow:
    def __init__(self) -> None:
        self.profile = Path.home() / ".local/share/nyvex-browser/Default"
        self.settings = SettingsStore(self.profile)
        self.engine = Engine()
        self.sessions = SessionStore(self.profile)
        self.closed = ClosedTabs()
        self.history = HistoryStore(self.profile)
        self.bookmarks = BookmarkStore(self.profile)
        self.tabs = TabManager()
        self.session = self.sessions.load()
        engine_id = self.settings.get("search_engine", "duckduckgo")

        # crash restore
        if self.sessions.crashed() and self.sessions.has_session_file():
            if messagebox.askyesno("Nyvex Browser", "Восстановить предыдущую сессию?"):
                try:
                    for t in self.session["windows"][0]["tabs"]:
                        self.tabs.new(t.get("url", "nyvex://home"), t.get("title", "Tab"))
                    self.tabs.active = min(
                        self.session["windows"][0].get("active_tab", 0),
                        max(0, len(self.tabs.tabs) - 1),
                    )
                except Exception:
                    self.tabs.new("nyvex://home")
            else:
                self.tabs.new("nyvex://home")
        else:
            try:
                saved = self.session["windows"][0]["tabs"]
                if saved and self.settings.get("startup") == "restore":
                    for t in saved:
                        self.tabs.new(t.get("url", "nyvex://home"), t.get("title", "Tab"))
                else:
                    self.tabs.new("nyvex://home")
            except Exception:
                self.tabs.new("nyvex://home")

        self.sessions.mark_dirty_start()
        self.omnibox = Omnibox(
            history_items=self.history._items,
            bookmark_items=self.bookmarks.list_flat(),
            engine_id=engine_id,
        )

        self.root = tk.Tk()
        self.root.title("Nyvex Browser")
        self.root.geometry("1100x700")
        self.root.configure(bg="#0b1020")
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        self.tabbar = tk.Frame(self.root, bg="#0d1424")
        self.tabbar.pack(fill=tk.X)
        tk.Button(self.tabbar, text="+", command=self.new_tab, bg="#1a2436", fg="#eef", relief=tk.FLAT, padx=10).pack(side=tk.RIGHT, padx=4, pady=3)

        bar = tk.Frame(self.root, bg="#121a28")
        bar.pack(fill=tk.X)
        for text, cmd in [("◀", self.back), ("▶", self.forward), ("↻", self.reload), ("⌂", self.home)]:
            tk.Button(bar, text=text, command=cmd, bg="#1a2436", fg="#eef", relief=tk.FLAT, padx=8).pack(side=tk.LEFT, padx=2, pady=4)
        self.urlbar = tk.Entry(bar, bg="#0b1020", fg="#eef", insertbackground="#eef")
        self.urlbar.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=6, pady=6)
        self.urlbar.bind("<Return>", lambda e: self.go())
        self.urlbar.bind("<KeyRelease>", self.on_type)
        tk.Button(bar, text="Go", command=self.go, bg="#8b5cf6", fg="#fff", relief=tk.FLAT, padx=12).pack(side=tk.LEFT, padx=4)

        self.suggest = tk.Listbox(self.root, bg="#121a28", fg="#eef", height=6, relief=tk.FLAT)
        self.suggest.bind("<Double-Button-1>", self.pick_suggest)
        self.suggest.bind("<Return>", self.pick_suggest)

        self.content = tk.Text(self.root, bg="#0b1020", fg="#e8ecff", wrap=tk.WORD, relief=tk.FLAT, font=("Sans", 11))
        self.content.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        self.status = tk.Label(self.root, text="Nyvex · поиск как Firefox (URL / d query / g query)", bg="#121a28", fg="#9aa3b5", anchor="w")
        self.status.pack(fill=tk.X)

        self.root.bind("<Control-t>", lambda e: self.new_tab())
        self.root.bind("<Control-w>", lambda e: self.close_tab())
        self.root.bind("<Control-Shift-T>", lambda e: self.restore_tab())
        self.root.bind("<Control-l>", lambda e: self.urlbar.focus_set())
        self.root.bind("<Control-r>", lambda e: self.reload())
        self.root.bind("<Control-k>", lambda e: self.focus_search())

        self.redraw_tabs()
        cur = self.tabs.current()
        self.show(cur["url"] if cur else "nyvex://home", record_history=False)

    def focus_search(self) -> None:
        self.urlbar.focus_set()
        self.urlbar.delete(0, tk.END)

    def on_type(self, _event=None) -> None:
        q = self.urlbar.get()
        self.omnibox.history = self.history._items
        self.omnibox.bookmark_items = self.bookmarks.list_flat()
        items = self.omnibox.suggest(q, limit=8)
        self.suggest.delete(0, tk.END)
        self._suggest_urls = []
        if not items:
            self.suggest.pack_forget()
            return
        for it in items:
            prefix = {"bookmark": "⭐", "history": "🕒", "search": "🔍", "url": "🔗"}.get(it["type"], "•")
            self.suggest.insert(tk.END, f"{prefix}  {it['title']}")
            self._suggest_urls.append(it["url"])
        self.suggest.pack(fill=tk.X, padx=8, before=self.content)

    def pick_suggest(self, _event=None) -> None:
        sel = self.suggest.curselection()
        if not sel:
            return
        url = self._suggest_urls[sel[0]]
        self.suggest.pack_forget()
        self.show(url)

    def persist(self) -> None:
        self.sessions.set_tabs(0, list(self.tabs.tabs), self.tabs.active)

    def redraw_tabs(self) -> None:
        for w in self.tabbar.winfo_children():
            if isinstance(w, tk.Button) and w.cget("text") != "+":
                w.destroy()
        for i, t in enumerate(self.tabs.tabs):
            title = (t.get("title") or t.get("url") or "Tab")[:22]
            bg = "#8b5cf6" if i == self.tabs.active else "#1a2436"
            tk.Button(self.tabbar, text=title, bg=bg, fg="#fff", relief=tk.FLAT, padx=8,
                      command=lambda idx=i: self.select_tab(idx)).pack(side=tk.LEFT, padx=2, pady=3)

    def select_tab(self, index: int) -> None:
        self.tabs.select(index)
        self.redraw_tabs()
        self.persist()
        cur = self.tabs.current()
        if cur:
            self.show(cur["url"], record_history=False)

    def new_tab(self) -> None:
        self.tabs.new("nyvex://home", "Home")
        self.redraw_tabs()
        self.persist()
        self.show("nyvex://home", record_history=False)

    def close_tab(self) -> None:
        if len(self.tabs.tabs) <= 1:
            self.on_close()
            return
        closed = self.tabs.close()
        if closed:
            self.closed.push(closed)
        self.redraw_tabs()
        self.persist()
        cur = self.tabs.current()
        if cur:
            self.show(cur["url"], record_history=False)

    def restore_tab(self) -> None:
        item = self.closed.pop()
        if not item:
            self.status.config(text="Нет закрытых вкладок")
            return
        self.tabs.new(item.get("url", "nyvex://home"), item.get("title", "Tab"))
        self.redraw_tabs()
        self.persist()
        self.show(item.get("url", "nyvex://home"), record_history=False)

    def show(self, url: str, record_history: bool = True) -> None:
        self.engine.load(url)
        if self.tabs.current():
            self.tabs.set_url(url)
            self.tabs.tabs[self.tabs.active]["title"] = (
                (resolve(url) or "nyvex") if is_internal(url) else url
            )[:40]
        self.urlbar.delete(0, tk.END)
        self.urlbar.insert(0, url)
        self.suggest.pack_forget()
        self.content.delete("1.0", tk.END)
        if is_internal(url):
            page = resolve(url) or "page"
            self.content.insert(tk.END, f"── Nyvex · {page} ──\n\n{render_stub(page)}\n")
            self.content.insert(tk.END, "\nПоиск: текст → DuckDuckGo · g запрос · d запрос · Ctrl+K\n")
        else:
            if record_history:
                self.history.add(url, url)
            probe = self.engine.gecko.probe_https(url) if url.startswith("https://") else {}
            self.content.insert(tk.END, f"URL: {url}\nHTTPS: {probe}\n\n")
            self.content.insert(tk.END, "Рендер страницы (WebKit/Gecko) — следующий шаг.\n")
        self.redraw_tabs()
        self.persist()
        self.status.config(text=f"{url}  ·  tabs:{len(self.tabs.tabs)}  ·  search:{self.settings.get('search_engine')}")

    def go(self) -> None:
        text = self.urlbar.get()
        url = normalize_input(text, engine_id=self.settings.get("search_engine", "duckduckgo"))
        self.show(url)

    def back(self) -> None:
        self.engine.back()
        self.show(self.engine.url, record_history=False)

    def forward(self) -> None:
        self.engine.forward()
        self.show(self.engine.url, record_history=False)

    def reload(self) -> None:
        self.show(self.engine.url, record_history=False)

    def home(self) -> None:
        self.show("nyvex://home")

    def on_close(self) -> None:
        self.persist()
        self.sessions.mark_clean_shutdown()
        self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()

def main():
    NyvexWindow().run()

if __name__ == "__main__":
    main()
