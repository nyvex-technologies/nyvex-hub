"""Диалог темы / обоев / языка."""
from __future__ import annotations
from gi.repository import Gtk
from themes.catalog import all_themes
from themes.wallpapers import WALLPAPERS
from i18n.catalog import languages

def pick_appearance(parent, settings) -> None:
    dlg = Gtk.Dialog(title="Appearance · Nyvex", transient_for=parent, modal=True)
    dlg.add_button("OK", Gtk.ResponseType.OK)
    dlg.set_default_size(420, 320)
    box = dlg.get_content_area()
    box.set_spacing(10)
    box.set_margin_top(12)
    box.set_margin_bottom(12)
    box.set_margin_start(12)
    box.set_margin_end(12)

    def row(label, combo):
        h = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        h.pack_start(Gtk.Label(label=label, xalign=0), False, False, 0)
        h.pack_start(combo, True, True, 0)
        box.add(h)
        return combo

    themes = all_themes()
    ct = Gtk.ComboBoxText()
    for t in themes:
        ct.append(t["id"], t["name"])
    ct.set_active_id(settings.get("theme", "nyvex-violet"))
    row("Theme", ct)

    cw = Gtk.ComboBoxText()
    for w in WALLPAPERS:
        cw.append(w["id"], w["name"])
    cw.set_active_id(settings.get("wallpaper", "aurora"))
    row("Wallpaper", cw)

    cl = Gtk.ComboBoxText()
    for code, name in languages():
        cl.append(code, f"{name} ({code})")
    cl.set_active_id(settings.get("locale", "ru"))
    row("Language", cl)

    dlg.show_all()
    if dlg.run() == Gtk.ResponseType.OK:
        if ct.get_active_id():
            settings.set("theme", ct.get_active_id())
        if cw.get_active_id():
            settings.set("wallpaper", cw.get_active_id())
        if cl.get_active_id():
            settings.set("locale", cl.get_active_id())
    dlg.destroy()
