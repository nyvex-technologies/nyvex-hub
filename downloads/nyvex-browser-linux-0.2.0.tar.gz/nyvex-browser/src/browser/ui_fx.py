"""Nyvex Browser UI — themes, wallpapers, i18n, newtab."""
from __future__ import annotations
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import gi
gi.require_version("Gtk", "3.0")
try:
    gi.require_version("WebKit2", "4.1")
except ValueError:
    gi.require_version("WebKit2", "4.0")
from gi.repository import Gtk, WebKit2, Gdk, GLib

from core.branding import (
    APP_NAME, VERSION_LABEL, VENDOR, CREATOR, COPYRIGHT,
    SUPPORT_EMAIL, ENGINE_DETAIL, USER_AGENT,
)
from navigation.address import normalize_input
from sessions.store import SessionStore
from sessions.closed import ClosedTabs
from history.store import HistoryStore
from settings.store import SettingsStore
from themes.catalog import get_theme, gtk_css, all_themes
from themes.wallpapers import WALLPAPERS
from i18n.catalog import t, languages
from newtab.page import render_newtab
from browser.appearance import pick_appearance

class BrowserTab:
    def __init__(self, url: str, on_title, on_uri, wallpaper: str, ua: str):
        self.view = WebKit2.WebView()
        st = self.view.get_settings()
        st.set_enable_developer_extras(True)
        try:
            st.set_user_agent(ua)
        except Exception:
            pass
        self._wallpaper = wallpaper
        self._load(url)
        self.view.connect("notify::title", lambda *a: on_title(self))
        self.view.connect("notify::uri", lambda *a: on_uri(self))
        self.view.connect("load-changed", lambda v, e: on_uri(self))

    def _load(self, url: str) -> None:
        if url in ("nyvex://newtab", "nyvex://home", "about:blank"):
            html = render_newtab(self._wallpaper)
            self.view.load_html(html, "nyvex://newtab")
        else:
            self.view.load_uri(url)

class NyvexBrowser:
    def __init__(self):
        self.profile = Path.home() / ".local/share/nyvex-browser/Default"
        self.settings = SettingsStore(self.profile)
        self.sessions = SessionStore(self.profile)
        self.closed = ClosedTabs()
        self.history = HistoryStore(self.profile)
        self.session = self.sessions.load()
        self.engine_id = self.settings.get("search_engine", "duckduckgo")
        self.lang = self.settings.get("locale", "ru")
        self.wallpaper = self.settings.get("wallpaper", "aurora")
        self.theme_id = self.settings.get("theme", "nyvex-violet")
        hub = self.settings.get("hub_url") or "https://duckduckgo.com"
        self.hub_url = hub
        self.home_url = self.settings.get("home_url") or "nyvex://newtab"
        self.tabs: list[BrowserTab] = []
        self._css_provider = Gtk.CssProvider()

        self.win = Gtk.Window(title=APP_NAME)
        self.win.set_default_size(1280, 840)
        self.win.connect("destroy", self.on_quit)
        self.win.connect("key-press-event", self.on_key)

        self.root_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.win.add(self.root_box)

        # menu
        self.mb = Gtk.MenuBar()
        self.root_box.pack_start(self.mb, False, False, 0)
        self._build_menus()

        # toolbar
        self.tb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=3)
        self.tb.set_margin_top(4)
        self.tb.set_margin_bottom(4)
        self.tb.set_margin_start(8)
        self.tb.set_margin_end(8)
        self.root_box.pack_start(self.tb, False, False, 0)

        def ib(icon, cb, tip):
            b = Gtk.Button.new_from_icon_name(icon, Gtk.IconSize.BUTTON)
            b.set_tooltip_text(tip)
            b.connect("clicked", cb)
            self.tb.pack_start(b, False, False, 0)
            return b

        ib("go-previous-symbolic", self.go_back, t(self.lang, "back"))
        ib("go-next-symbolic", self.go_forward, t(self.lang, "forward"))
        ib("view-refresh-symbolic", self.reload, t(self.lang, "reload"))
        ib("go-home-symbolic", self.go_home, t(self.lang, "home"))
        self.btn_hub = Gtk.Button(label=t(self.lang, "hub"))
        self.btn_hub.connect("clicked", self.go_hub)
        self.tb.pack_start(self.btn_hub, False, False, 2)

        self.url = Gtk.Entry()
        self.url.set_placeholder_text(t(self.lang, "search_ph"))
        self.url.connect("activate", self.on_go)
        self.tb.pack_start(self.url, True, True, 6)

        self.btn_go = Gtk.Button(label=t(self.lang, "go"))
        self.btn_go.connect("clicked", self.on_go)
        self.tb.pack_start(self.btn_go, False, False, 0)
        ib("list-add-symbolic", lambda *_: self.new_tab(), t(self.lang, "new_tab"))
        self.btn_look = Gtk.Button(label="✦")
        self.btn_look.set_tooltip_text(t(self.lang, "theme") + " / " + t(self.lang, "wallpaper"))
        self.btn_look.connect("clicked", self.open_appearance)
        self.tb.pack_start(self.btn_look, False, False, 2)

        self.notebook = Gtk.Notebook()
        self.notebook.set_scrollable(True)
        self.notebook.connect("switch-page", self.on_switch)
        self.root_box.pack_start(self.notebook, True, True, 0)

        self.status = Gtk.Label(xalign=0)
        self.status.set_margin_start(10)
        self.status.set_margin_bottom(4)
        self.status.set_text(f"{APP_NAME} {VERSION_LABEL} · {VENDOR} · {ENGINE_DETAIL}")
        self.root_box.pack_start(self.status, False, False, 2)

        self.apply_theme()

        restored = False
        if self.sessions.crashed() and self.sessions.has_session_file():
            dlg = Gtk.MessageDialog(
                transient_for=self.win,
                message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.YES_NO,
                text=t(self.lang, "restore_session"),
            )
            if dlg.run() == Gtk.ResponseType.YES:
                try:
                    for tab in self.session["windows"][0]["tabs"]:
                        u = tab.get("url") or self.home_url
                        self.new_tab(u)
                    restored = True
                except Exception:
                    pass
            dlg.destroy()

        if not restored:
            self.new_tab(self.home_url)
            self.new_tab(self.hub_url)
            self.notebook.set_current_page(0)

        self.sessions.mark_dirty_start()
        self.win.show_all()

    def _build_menus(self) -> None:
        for child in self.mb.get_children():
            self.mb.remove(child)

        def menu(title):
            item = Gtk.MenuItem(label=title)
            m = Gtk.Menu()
            item.set_submenu(m)
            self.mb.append(item)
            return m

        def item(m, title, cb):
            it = Gtk.MenuItem(label=title)
            it.connect("activate", cb)
            m.append(it)

        mf = menu(t(self.lang, "file"))
        item(mf, t(self.lang, "new_tab"), lambda *_: self.new_tab())
        item(mf, t(self.lang, "close_tab"), lambda *_: self.close_tab_at(self.current_index()))
        item(mf, t(self.lang, "exit"), lambda *_: self.on_quit())

        mv = menu(t(self.lang, "settings"))
        item(mv, t(self.lang, "theme") + " / " + t(self.lang, "wallpaper") + " / " + t(self.lang, "language"), self.open_appearance)

        mh = menu(t(self.lang, "help"))
        item(mh, t(self.lang, "hub"), self.go_hub)
        item(mh, t(self.lang, "about"), self.show_about)
        self.mb.show_all()

    def apply_theme(self) -> None:
        theme = get_theme(self.theme_id)
        try:
            self._css_provider.load_from_data(gtk_css(theme))
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(),
                self._css_provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
            )
        except Exception as e:
            print("theme css:", e)

    def open_appearance(self, *_a) -> None:
        pick_appearance(self.win, self.settings)
        self.theme_id = self.settings.get("theme", self.theme_id)
        self.wallpaper = self.settings.get("wallpaper", self.wallpaper)
        self.lang = self.settings.get("locale", self.lang)
        self.apply_theme()
        self._build_menus()
        self.url.set_placeholder_text(t(self.lang, "search_ph"))
        self.btn_go.set_label(t(self.lang, "go"))
        self.btn_hub.set_label(t(self.lang, "hub"))
        self.win.show_all()

    def show_about(self, *_a) -> None:
        d = Gtk.AboutDialog(transient_for=self.win, modal=True)
        d.set_program_name(APP_NAME)
        d.set_version(VERSION_LABEL)
        d.set_copyright(COPYRIGHT)
        d.set_comments(f"{VENDOR}\n{CREATOR}\n{ENGINE_DETAIL}\nThemes: {len(all_themes())} · Wallpapers: {len(WALLPAPERS)}")
        d.set_authors([CREATOR, VENDOR])
        d.set_license_type(Gtk.License.CUSTOM)
        d.set_license(f"{APP_NAME}\n{COPYRIGHT}\n{SUPPORT_EMAIL}")
        d.set_logo_icon_name("web-browser")
        d.run()
        d.destroy()

    def make_tab_label(self, title: str, tab: BrowserTab) -> Gtk.Box:
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        lab = Gtk.Label(label=(title or "Tab")[:24])
        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.get_style_context().add_class("tab-close")
        btn.add(Gtk.Image.new_from_icon_name("window-close-symbolic", Gtk.IconSize.MENU))
        btn.connect("clicked", lambda *_: self.close_tab_obj(tab))
        box.pack_start(lab, True, True, 0)
        box.pack_start(btn, False, False, 0)
        box.show_all()
        box._label = lab
        return box

    def current_index(self) -> int:
        return self.notebook.get_current_page()

    def current_view(self):
        i = self.current_index()
        return self.tabs[i].view if 0 <= i < len(self.tabs) else None

    def new_tab(self, url: str | None = None) -> None:
        url = url or self.home_url
        tab = BrowserTab(url, self.on_title, self.on_uri, self.wallpaper, USER_AGENT)
        self.tabs.append(tab)
        self.notebook.append_page(tab.view, self.make_tab_label("New", tab))
        self.notebook.set_tab_reorderable(tab.view, True)
        self.notebook.set_current_page(len(self.tabs) - 1)
        self.notebook.show_all()
        self.persist()

    def close_tab_obj(self, tab: BrowserTab) -> None:
        try:
            self.close_tab_at(self.tabs.index(tab))
        except ValueError:
            pass

    def close_tab_at(self, i: int) -> None:
        if i < 0 or i >= len(self.tabs):
            return
        if len(self.tabs) <= 1:
            self.tabs[0]._wallpaper = self.wallpaper
            self.tabs[0]._load(self.home_url)
            return
        tab = self.tabs.pop(i)
        self.closed.push({"url": tab.view.get_uri() or self.home_url, "title": tab.view.get_title() or "Tab"})
        self.notebook.remove_page(i)
        self.persist()

    def restore_closed(self) -> None:
        item = self.closed.pop()
        if item:
            self.new_tab(item.get("url") or self.home_url)

    def on_title(self, tab: BrowserTab) -> None:
        try:
            i = self.tabs.index(tab)
            title = tab.view.get_title() or "Tab"
            child = self.notebook.get_nth_page(i)
            lab = self.notebook.get_tab_label(child)
            if lab and hasattr(lab, "_label"):
                lab._label.set_text(title[:24])
            self.win.set_title(f"{title} — {APP_NAME}")
        except Exception:
            pass

    def on_uri(self, tab: BrowserTab) -> None:
        if self.current_view() is tab.view:
            uri = tab.view.get_uri() or ""
            self.url.set_text(uri)
            if uri.startswith("http"):
                self.history.add(uri, tab.view.get_title() or uri)
            self.status.set_text(f"{uri[:90]}  ·  {APP_NAME} {VERSION_LABEL}")
        self.persist()

    def on_switch(self, _n, _p, num: int) -> None:
        if 0 <= num < len(self.tabs):
            self.url.set_text(self.tabs[num].view.get_uri() or "")

    def on_go(self, *_a) -> None:
        dest = normalize_input(self.url.get_text(), engine_id=self.engine_id)
        v = self.current_view()
        if not v:
            return
        i = self.current_index()
        if dest.startswith("nyvex://"):
            self.tabs[i]._wallpaper = self.wallpaper
            self.tabs[i]._load(dest)
        else:
            v.load_uri(dest)

    def go_back(self, *_a) -> None:
        v = self.current_view()
        if v and v.can_go_back():
            v.go_back()

    def go_forward(self, *_a) -> None:
        v = self.current_view()
        if v and v.can_go_forward():
            v.go_forward()

    def reload(self, *_a) -> None:
        v = self.current_view()
        if v:
            v.reload()

    def go_home(self, *_a) -> None:
        i = self.current_index()
        if 0 <= i < len(self.tabs):
            self.tabs[i]._wallpaper = self.wallpaper
            self.tabs[i]._load(self.home_url)

    def go_hub(self, *_a) -> None:
        v = self.current_view()
        if v:
            v.load_uri(self.hub_url)

    def on_key(self, _w, event) -> bool:
        ctrl = bool(event.state & Gdk.ModifierType.CONTROL_MASK)
        shift = bool(event.state & Gdk.ModifierType.SHIFT_MASK)
        key = event.keyval
        if ctrl and key in (ord("t"), ord("T")):
            self.new_tab(); return True
        if ctrl and shift and key in (ord("t"), ord("T")):
            self.restore_closed(); return True
        if ctrl and key in (ord("w"), ord("W")):
            self.close_tab_at(self.current_index()); return True
        if ctrl and key in (ord("l"), ord("L"), ord("k"), ord("K")):
            self.url.grab_focus(); return True
        if ctrl and key in (ord("r"), ord("R")):
            self.reload(); return True
        if key == Gdk.KEY_F5:
            self.reload(); return True
        return False

    def persist(self) -> None:
        tabs = []
        for t_ in self.tabs:
            uri = t_.view.get_uri() or self.home_url
            tabs.append({"url": uri, "title": t_.view.get_title() or "Tab", "pinned": False})
        if tabs:
            self.sessions.set_tabs(0, tabs, max(0, self.current_index()))

    def on_quit(self, *_a) -> None:
        self.persist()
        self.sessions.mark_clean_shutdown()
        Gtk.main_quit()

def main():
    NyvexBrowser()
    Gtk.main()

if __name__ == "__main__":
    main()
