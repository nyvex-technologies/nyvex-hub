from __future__ import annotations
from pathlib import Path
from typing import Any
from sessions.store import SessionStore
from browser.engine import Engine
from history.store import HistoryStore
from bookmarks.store import BookmarkStore
from downloads.manager import DownloadManager
from privacy.center import PrivacyCenter
from permissions.site import SitePermissions
from security.sandbox import SecurityLayer
from proxy.config import ProxyConfig
from passwords.vault import PasswordVault
from settings.store import SettingsStore
from themes.manager import ThemeManager
from profiles.manager import ProfileManager
from diagnostics.info import Diagnostics
from navigation.address import normalize_input

class NyvexBrowserApp:
    def __init__(self) -> None:
        self.profile = Path.home() / ".local/share/nyvex-browser/Default"
        self.sessions = SessionStore(self.profile)
        self.engine = Engine()
        self.history = HistoryStore(self.profile)
        self.bookmarks = BookmarkStore(self.profile)
        self.downloads = DownloadManager()
        self.privacy = PrivacyCenter()
        self.permissions = SitePermissions()
        self.security = SecurityLayer()
        self.proxy = ProxyConfig()
        self.passwords = PasswordVault()
        self.settings = SettingsStore(self.profile)
        self.themes = ThemeManager()
        self.profiles = ProfileManager()
        self.diagnostics = Diagnostics()
        self.session = self.sessions.load()
        self.sessions.mark_dirty_start()

    def navigate(self, text: str) -> str:
        url = normalize_input(text)
        self.engine.load(url)
        if not url.startswith("nyvex://") and not self.privacy.private:
            self.history.add(url, url)
        return url

    def module_matrix(self) -> list[dict[str, Any]]:
        return [m.status() for m in [
            self.engine.gecko, self.privacy, self.permissions, self.security, self.proxy,
            self.passwords, self.settings, self.themes, self.profiles, self.diagnostics,
        ]]

    def shutdown(self) -> None:
        self.sessions.mark_clean_shutdown()
