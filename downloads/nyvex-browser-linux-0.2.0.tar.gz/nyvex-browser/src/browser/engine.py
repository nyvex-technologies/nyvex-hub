"""Навигационный движок вкладки (история URL). Gecko load — через runtime."""
from __future__ import annotations
from gecko.runtime import GeckoRuntime

class Engine:
    def __init__(self) -> None:
        self.url = "nyvex://home"
        self.title = "Home"
        self.loading = False
        self._history: list[str] = [self.url]
        self._index = 0
        self.gecko = GeckoRuntime()

    def load(self, url: str) -> None:
        self.loading = True
        self.url = url
        self._history = self._history[: self._index + 1]
        self._history.append(url)
        self._index = len(self._history) - 1
        self.title = url
        self.loading = False

    def back(self) -> None:
        if self.can_go_back():
            self._index -= 1
            self.url = self._history[self._index]

    def forward(self) -> None:
        if self.can_go_forward():
            self._index += 1
            self.url = self._history[self._index]

    def reload(self) -> None:
        self.load(self.url)

    def can_go_back(self) -> bool:
        return self._index > 0

    def can_go_forward(self) -> bool:
        return self._index < len(self._history) - 1
