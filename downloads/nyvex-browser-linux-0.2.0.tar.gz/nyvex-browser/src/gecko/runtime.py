"""Пункт 3/48 — слой Gecko.
Реальный libxul/embedding подключается здесь позже.
Сейчас: контракт + subprocess-проверка HTTPS через системный инструмент.
"""
from __future__ import annotations
import shutil, subprocess, urllib.request
from typing import Any

class GeckoRuntime:
    def __init__(self) -> None:
        self._ready = False
        self.backend = "stub"
        if shutil.which("firefox"):
            self.backend = "firefox-system"  # целевой движок установлен в ОС

    def status(self) -> dict[str, Any]:
        return {"module": "GeckoRuntime", "ready": self._ready, "backend": self.backend}

    def probe_https(self, url: str = "https://example.com", timeout: float = 8.0) -> dict[str, Any]:
        """Проверка сети/HTTPS до полной интеграции Gecko."""
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "NyvexBrowser/0.1"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                code = getattr(r, "status", 200)
                return {"ok": True, "url": url, "status": code}
        except Exception as e:
            return {"ok": False, "url": url, "error": str(e)}

    def has_firefox(self) -> bool:
        return shutil.which("firefox") is not None
