"""Обои новой вкладки."""
from __future__ import annotations

WALLPAPERS: list[dict[str, str]] = [
    {"id": "aurora", "name": "Aurora", "css": "linear-gradient(135deg,#0b1020 0%,#4c1d95 50%,#0ea5e9 100%)"},
    {"id": "ember", "name": "Ember", "css": "linear-gradient(160deg,#1a0b0a,#7c2d12,#f59e0b)"},
    {"id": "mint", "name": "Mint Depth", "css": "linear-gradient(145deg,#022c22,#115e59,#5eead4)"},
    {"id": "violet-haze", "name": "Violet Haze", "css": "linear-gradient(120deg,#14081f,#6d28d9,#c026d3)"},
    {"id": "ocean-glass", "name": "Ocean Glass", "css": "linear-gradient(180deg,#020617,#0c4a6e,#38bdf8)"},
    {"id": "noir", "name": "Noir", "css": "linear-gradient(180deg,#000,#1c1b22 60%,#3f3f46)"},
    {"id": "peach", "name": "Peach Sky", "css": "linear-gradient(135deg,#431407,#fb7185,#fdba74)"},
    {"id": "forest-mist", "name": "Forest Mist", "css": "linear-gradient(160deg,#022c22,#14532d,#86efac)"},
    {"id": "cosmic", "name": "Cosmic", "css": "radial-gradient(circle at 30% 20%,#7c3aed55,transparent 40%),radial-gradient(circle at 70% 60%,#06b6d455,transparent 40%),#0b1020"},
    {"id": "gold", "name": "Gold Hour", "css": "linear-gradient(145deg,#1c1917,#a16207,#fde68a)"},
]
# 40 фото-заглушек
for i in range(1, 41):
    WALLPAPERS.append({
        "id": f"photo-{i}",
        "name": f"Photo {i}",
        "css": f"url('https://picsum.photos/seed/nyvex{i}/1600/900') center/cover no-repeat",
    })

def get_wallpaper(wid: str) -> dict[str, str]:
    for w in WALLPAPERS:
        if w["id"] == wid:
            return w
    return WALLPAPERS[0]
