from __future__ import annotations
from typing import Any
THEMES = {"nyvex-dark": "#0b1020", "nyvex-light": "#f5f7ff", "system": None}
class ThemeManager:
    def __init__(self) -> None:
        self.current = "nyvex-dark"
    def status(self) -> dict[str, Any]:
        return {"module": "ThemeManager", "ready": True, "theme": self.current, "available": list(THEMES)}
