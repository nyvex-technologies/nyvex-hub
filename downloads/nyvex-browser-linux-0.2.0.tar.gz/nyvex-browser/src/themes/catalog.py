"""Каталог тем Nyvex Browser."""
from __future__ import annotations
from typing import Any

# базовые пресеты
_BASE: list[dict[str, str]] = [
    {"id": "nyvex-dark", "name": "Nyvex Dark", "bg": "#0b1020", "fg": "#e8ecff", "accent": "#8b5cf6", "panel": "#121a28", "input": "#1a2436"},
    {"id": "nyvex-violet", "name": "Nyvex Violet", "bg": "#14081f", "fg": "#f3e8ff", "accent": "#a855f7", "panel": "#1f1030", "input": "#2a1845"},
    {"id": "midnight", "name": "Midnight", "bg": "#0a0e17", "fg": "#e6edf7", "accent": "#3b82f6", "panel": "#111827", "input": "#1f2937"},
    {"id": "graphite", "name": "Graphite", "bg": "#1c1b22", "fg": "#fbfbfe", "accent": "#bfb8cc", "panel": "#2b2a33", "input": "#3a3942"},
    {"id": "ocean", "name": "Ocean", "bg": "#061820", "fg": "#e0f7fa", "accent": "#06b6d4", "panel": "#0c2a35", "input": "#13404f"},
    {"id": "forest", "name": "Forest", "bg": "#0a160e", "fg": "#e8ffe9", "accent": "#22c55e", "panel": "#12261a", "input": "#1a3324"},
    {"id": "sunset", "name": "Sunset", "bg": "#1a0b0a", "fg": "#fff1e6", "accent": "#f97316", "panel": "#2a1410", "input": "#3d1f18"},
    {"id": "rose", "name": "Rose", "bg": "#1a0a12", "fg": "#ffe4ef", "accent": "#f43f5e", "panel": "#2a1220", "input": "#3d1a2e"},
    {"id": "amber", "name": "Amber", "bg": "#1a1205", "fg": "#fff8e7", "accent": "#f59e0b", "panel": "#2a1e0c", "input": "#3d2c12"},
    {"id": "nord", "name": "Nord", "bg": "#2e3440", "fg": "#eceff4", "accent": "#88c0d0", "panel": "#3b4252", "input": "#434c5e"},
    {"id": "dracula", "name": "Dracula", "bg": "#282a36", "fg": "#f8f8f2", "accent": "#bd93f9", "panel": "#21222c", "input": "#44475a"},
    {"id": "solarized-dark", "name": "Solarized Dark", "bg": "#002b36", "fg": "#fdf6e3", "accent": "#268bd2", "panel": "#073642", "input": "#094552"},
    {"id": "monokai", "name": "Monokai", "bg": "#272822", "fg": "#f8f8f2", "accent": "#a6e22e", "panel": "#1e1f1c", "input": "#3e3d32"},
    {"id": "light", "name": "Light", "bg": "#f5f7ff", "fg": "#0f172a", "accent": "#7c3aed", "panel": "#ffffff", "input": "#e8ecf8"},
    {"id": "paper", "name": "Paper", "bg": "#faf7f2", "fg": "#1c1917", "accent": "#b45309", "panel": "#ffffff", "input": "#f0ebe3"},
    {"id": "ice", "name": "Ice", "bg": "#e8f4fc", "fg": "#0c4a6e", "accent": "#0284c7", "panel": "#f0f9ff", "input": "#dbeafe"},
    {"id": "sakura", "name": "Sakura", "bg": "#1a1016", "fg": "#ffe4ec", "accent": "#fb7185", "panel": "#2a1822", "input": "#3d2432"},
    {"id": "matrix", "name": "Matrix", "bg": "#020b05", "fg": "#a7f3d0", "accent": "#4ade80", "panel": "#04150a", "input": "#0a2814"},
    {"id": "cyber", "name": "Cyberpunk", "bg": "#0c0614", "fg": "#f0abfc", "accent": "#e879f9", "panel": "#1a0b28", "input": "#2a1240"},
    {"id": "coffee", "name": "Coffee", "bg": "#1c1410", "fg": "#f5e6d3", "accent": "#d6a574", "panel": "#2a1f18", "input": "#3d2e24"},
]

def _hex_shift(h: str, dh: int) -> str:
    h = h.lstrip("#")
    if len(h) != 6:
        return "#" + h
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    def clamp(x): return max(0, min(255, x + dh))
    return f"#{clamp(r):02x}{clamp(g):02x}{clamp(b):02x}"

def all_themes() -> list[dict[str, Any]]:
    out = []
    for base in _BASE:
        out.append(dict(base))
        for i, delta in enumerate((-25, -12, 12, 25, 40), start=1):
            t = dict(base)
            t["id"] = f"{base['id']}-v{i}"
            t["name"] = f"{base['name']} · {i}"
            t["bg"] = _hex_shift(base["bg"], delta // 3)
            t["panel"] = _hex_shift(base["panel"], delta // 3)
            t["input"] = _hex_shift(base["input"], delta // 2)
            t["accent"] = _hex_shift(base["accent"], delta // 4)
            out.append(t)
    # ещё сетка акцентов
    accents = ["#ef4444","#f97316","#eab308","#84cc16","#22c55e","#14b8a6","#06b6d4","#3b82f6","#6366f1","#8b5cf6","#d946ef","#ec4899"]
    for n, acc in enumerate(accents):
        out.append({
            "id": f"accent-{n}",
            "name": f"Accent {n+1}",
            "bg": "#0b1020", "fg": "#e8ecff", "accent": acc,
            "panel": "#121a28", "input": "#1a2436",
        })
    return out

def get_theme(theme_id: str) -> dict[str, Any]:
    for t in all_themes():
        if t["id"] == theme_id:
            return t
    return all_themes()[0]

def gtk_css(theme: dict[str, str]) -> bytes:
    css = f"""
    window, notebook, box {{ background: {theme['bg']}; color: {theme['fg']}; }}
    entry {{
        min-height: 34px; border-radius: 10px; padding: 4px 12px;
        background: {theme['input']}; color: {theme['fg']};
        border: 1px solid {theme['accent']}55;
    }}
    button {{
        min-height: 32px; border-radius: 8px; padding: 2px 10px;
        background: {theme['panel']}; color: {theme['fg']};
        border: 1px solid {theme['accent']}33;
    }}
    button:hover {{ background: {theme['accent']}33; }}
    notebook tab {{
        background: {theme['panel']}; color: {theme['fg']};
        padding: 6px 8px; border-radius: 8px 8px 0 0;
    }}
    notebook tab:checked {{ background: {theme['accent']}44; }}
    menubar, menu {{ background: {theme['panel']}; color: {theme['fg']}; }}
    menuitem:hover {{ background: {theme['accent']}44; }}
    .tab-close {{ padding: 0; min-width: 22px; min-height: 22px; border: none; }}
    label {{ color: {theme['fg']}; }}
    """
    return css.encode("utf-8")
