from __future__ import annotations
from themes.wallpapers import get_wallpaper
from core.branding import APP_NAME, VERSION_LABEL, CREATOR, VENDOR

def render_newtab(wallpaper_id: str = "aurora") -> str:
    wp = get_wallpaper(wallpaper_id)
    return f"""<!DOCTYPE html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>New Tab — {APP_NAME}</title>
<style>
html,body{{margin:0;height:100%;font-family:system-ui,sans-serif;color:#fff}}
.bg{{position:fixed;inset:0;background:{wp['css']};filter:brightness(.85)}}
.wrap{{position:relative;z-index:1;min-height:100%;display:flex;flex-direction:column;
align-items:center;justify-content:center;padding:24px;text-align:center}}
h1{{font-size:42px;font-weight:800;margin:0 0 8px;letter-spacing:-.03em;
text-shadow:0 8px 40px #0008}}
p{{opacity:.85;margin:0 0 28px}}
form{{display:flex;gap:8px;width:min(560px,100%)}}
input{{flex:1;border:none;border-radius:14px;padding:14px 18px;font-size:16px;
background:#ffffff22;color:#fff;outline:none;backdrop-filter:blur(8px);
border:1px solid #ffffff33}}
input::placeholder{{color:#ffffff99}}
button{{border:none;border-radius:14px;padding:14px 20px;font-weight:700;
background:#8b5cf6;color:#fff;cursor:pointer}}
.links{{margin-top:28px;display:flex;gap:12px;flex-wrap:wrap;justify-content:center}}
.links a{{color:#fff;text-decoration:none;background:#ffffff18;padding:8px 14px;
border-radius:999px;border:1px solid #ffffff22;font-size:13px}}
.foot{{position:fixed;bottom:16px;opacity:.6;font-size:12px}}
</style></head><body>
<div class="bg"></div>
<div class="wrap">
 <h1>{APP_NAME}</h1>
 <p>{VENDOR} · {CREATOR}</p>
 <form action="https://duckduckgo.com/" method="get">
  <input name="q" placeholder="Search the web…" autofocus>
  <button type="submit">Search</button>
 </form>
 <div class="links">
  <a href="https://duckduckgo.com">DuckDuckGo</a>
  <a href="https://github.com">GitHub</a>
  <a href="https://wikipedia.org">Wikipedia</a>
 </div>
</div>
<div class="foot">{APP_NAME} {VERSION_LABEL}</div>
</body></html>"""
