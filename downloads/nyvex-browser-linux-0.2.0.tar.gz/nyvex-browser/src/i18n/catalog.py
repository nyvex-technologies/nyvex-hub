"""Локализация интерфейса Nyvex Browser."""
from __future__ import annotations

# ключи UI
_KEYS = ["file", "help", "new_tab", "close_tab", "exit", "about", "hub", "back", "forward", "reload", "home", "go", "search_ph", "restore_session", "settings", "theme", "wallpaper", "language"]

# минимальные переводы (язык -> строки в том же порядке что _KEYS)
_RAW: dict[str, list[str]] = {
"en": ["File","Help","New tab","Close tab","Exit","About","Hub","Back","Forward","Reload","Home","Go","Search or address","Restore previous session?","Settings","Theme","Wallpaper","Language"],
"ru": ["Файл","Справка","Новая вкладка","Закрыть вкладку","Выход","О программе","Hub","Назад","Вперёд","Обновить","Домой","Перейти","Поиск или адрес","Восстановить сессию?","Настройки","Тема","Обои","Язык"],
"uk": ["Файл","Довідка","Нова вкладка","Закрити вкладку","Вихід","Про програму","Hub","Назад","Вперед","Оновити","Домівка","Перейти","Пошук або адреса","Відновити сесію?","Налаштування","Тема","Шпалери","Мова"],
"de": ["Datei","Hilfe","Neuer Tab","Tab schließen","Beenden","Über","Hub","Zurück","Vor","Neu laden","Start","Los","Suche oder Adresse","Sitzung wiederherstellen?","Einstellungen","Design","Hintergrund","Sprache"],
"fr": ["Fichier","Aide","Nouvel onglet","Fermer l'onglet","Quitter","À propos","Hub","Retour","Avant","Actualiser","Accueil","Go","Recherche ou adresse","Restaurer la session ?","Paramètres","Thème","Fond","Langue"],
"es": ["Archivo","Ayuda","Nueva pestaña","Cerrar pestaña","Salir","Acerca de","Hub","Atrás","Adelante","Recargar","Inicio","Ir","Buscar o dirección","¿Restaurar sesión?","Ajustes","Tema","Fondo","Idioma"],
"it": ["File","Aiuto","Nuova scheda","Chiudi scheda","Esci","Informazioni","Hub","Indietro","Avanti","Ricarica","Home","Vai","Cerca o indirizzo","Ripristinare sessione?","Impostazioni","Tema","Sfondo","Lingua"],
"pt": ["Arquivo","Ajuda","Nova aba","Fechar aba","Sair","Sobre","Hub","Voltar","Avançar","Recarregar","Início","Ir","Pesquisar ou endereço","Restaurar sessão?","Configurações","Tema","Papel de parede","Idioma"],
"pl": ["Plik","Pomoc","Nowa karta","Zamknij kartę","Zakończ","O programie","Hub","Wstecz","Dalej","Odśwież","Start","Idź","Szukaj lub adres","Przywrócić sesję?","Ustawienia","Motyw","Tapeta","Język"],
"tr": ["Dosya","Yardım","Yeni sekme","Sekmeyi kapat","Çıkış","Hakkında","Hub","Geri","İleri","Yenile","Ana sayfa","Git","Ara veya adres","Oturum kurtar belirsiz?","Ayarlar","Tema","Duvar kağıdı","Dil"],
"ar": ["ملف","مساعدة","علامة تبويب جديدة","إغلاق","خروج","حول","Hub","رجوع","أمام","تحديث","الرئيسية","اذهب","بحث أو عنوان","استعادة الجلسة؟","إعدادات","سمة","خلفية","لغة"],
"zh": ["文件","帮助","新标签","关闭标签","退出","关于","Hub","后退","前进","刷新","主页","转至","搜索或地址","恢复会话？","设置","主题","壁纸","语言"],
"ja": ["ファイル","ヘルプ","新しいタブ","タブを閉じる","終了","について","Hub","戻る","進む","再読込","ホーム","移動","検索またはURL","セッションを復元？","設定","テーマ","壁紙","言語"],
"ko": ["파일","도움말","새 탭","탭 닫기","종료","정보","Hub","뒤로","앞으로","새로고침","홈","이동","검색 또는 주소","세션 복원?","설정","테마","배경","언어"],
"hi": ["फ़ाइल","मदद","नया टैब","टैब बंद","बाहर","के बारे में","Hub","पीछे","आगे","रीलोड","होम","जाएँ","खोज या पता","सत्र पुनर्स्थापित?","सेटिंग","थीम","वॉलपेपर","भाषा"],
"nl": ["Bestand","Help","Nieuw tabblad","Tab sluiten","Afsluiten","Over","Hub","Terug","Vooruit","Vernieuwen","Home","Ga","Zoek of adres","Sessie herstellen?","Instellingen","Thema","Achtergrond","Taal"],
"sv": ["Arkiv","Hjälp","Ny flik","Stäng flik","Avsluta","Om","Hub","Tillbaka","Framåt","Ladda om","Hem","Gå","Sök eller adress","Återställ session?","Inställningar","Tema","Bakgrund","Språk"],
"cs": ["Soubor","Nápověda","Nová karta","Zavřít kartu","Ukončit","O aplikaci","Hub","Zpět","Vpřed","Obnovit","Domů","Jít","Hledat nebo adresa","Obnovit relaci?","Nastavení","Motiv","Tapeta","Jazyk"],
"ro": ["Fișier","Ajutor","Filă nouă","Închide fila","Ieșire","Despre","Hub","Înapoi","Înainte","Reîncărcare","Acasă","Du-te","Căutare sau adresă","Restaurezi sesiunea?","Setări","Temă","Fundal","Limbă"],
"el": ["Αρχείο","Βοήθεια","Νέα καρτέλα","Κλείσιμο","Έξοδος","Περί","Hub","Πίσω","Εμπρός","Ανανέωση","Αρχική","Μετάβαση","Αναζήτηση ή διεύθυνση","Επαναφορά συνεδρίας;","Ρυθμίσεις","Θέμα","Ταπετσαρία","Γλώσσα"],
"he": ["קובץ","עזרה","כרטיסייה חדשה","סגור","יציאה","אודות","Hub","חזרה","קדימה","רענן","בית","עבור","חיפוש או כתובת","שחזר הפעלה?","הגדרות","ערכת נושא","רקע","שפה"],
"vi": ["Tệp","Trợ giúp","Tab mới","Đóng tab","Thoát","Giới thiệu","Hub","Quay lại","Tiến","Tải lại","Trang chủ","Đi","Tìm hoặc địa chỉ","Khôi phục phiên?","Cài đặt","Chủ đề","Hình nền","Ngôn ngữ"],
"th": ["ไฟล์","ช่วยเหลือ","แท็บใหม่","ปิดแท็บ","ออก","เกี่ยวกับ","Hub","กลับ","ไปหน้า","โหลดใหม่","หน้าหลัก","ไป","ค้นหาหรือที่อยู่","กู้คืนเซสชัน?","ตั้งค่า","ธีม","วอลล์เปเปอร์","ภาษา"],
"id": ["Berkas","Bantuan","Tab baru","Tutup tab","Keluar","Tentang","Hub","Kembali","Maju","Muat ulang","Beranda","Buka","Cari atau alamat","Pulihkan sesi?","Pengaturan","Tema","Wallpaper","Bahasa"],
"ms": ["Fail","Bantuan","Tab baharu","Tutup tab","Keluar","Perihal","Hub","Undur","Maju","Muat semula","Laman utama","Pergi","Cari atau alamat","Pulihkan sesi?","Tetapan","Tema","Kertas dinding","Bahasa"],
"fi": ["Tiedosto","Ohje","Uusi välilehti","Sulje","Lopeta","Tietoja","Hub","Takaisin","Eteen","Päivitä","Koti","Siirry","Haku tai osoite","Palauta istunto?","Asetukset","Teema","Tausta","Kieli"],
"da": ["Fil","Hjælp","Ny fane","Luk fane","Afslut","Om","Hub","Tilbage","Frem","Genindlæs","Hjem","Gå","Søg eller adresse","Gendan session?","Indstillinger","Tema","Baggrund","Sprog"],
"no": ["Fil","Hjelp","Ny fane","Lukk fane","Avslutt","Om","Hub","Tilbake","Frem","Oppdater","Hjem","Gå","Søk eller adresse","Gjenopprett økt?","Innstillinger","Tema","Bakgrunn","Språk"],
"hu": ["Fájl","Súgó","Új lap","Lap bezárása","Kilépés","Névjegy","Hub","Vissza","Előre","Újratöltés","Kezdőlap","Ugrás","Keresés vagy cím","Munkamenet vissza?","Beállítások","Téma","Háttér","Nyelv"],
"sk": ["Súbor","Pomocník","Nová karta","Zavrieť","Ukončiť","O programe","Hub","Späť","Dopredu","Obnoviť","Domov","Ísť","Hľadať alebo adresa","Obnoviť reláciu?","Nastavenia","Motív","Tapeta","Jazyk"],
"bg": ["Файл","Помощ","Нов раздел","Затвори","Изход","Относно","Hub","Назад","Напред","Презареди","Начало","Напред","Търсене или адрес","Възстанови сесията?","Настройки","Тема","Тапет","Език"],
"sr": ["Датотека","Помоћ","Нова картица","Затвори","Излаз","О програму","Hub","Назад","Напред","Освежи","Почетна","Иди","Претрага или адреса","Врати сесију?","Подешавања","Тема","Позадина","Језик"],
"hr": ["Datoteka","Pomoć","Nova kartica","Zatvori","Izlaz","O programu","Hub","Natrag","Naprijed","Osvježi","Početna","Idi","Traži ili adresa","Vrati sesiju?","Postavke","Tema","Pozadina","Jezik"],
"lt": ["Failas","Pagalba","Nauja kortelė","Uždaryti","Išeiti","Apie","Hub","Atgal","Pirmyn","Atnaujinti","Pradžia","Eiti","Paieška arba adresas","Atkurti sesiją?","Nustatymai","Tema","Fonai","Kalba"],
"lv": ["Fails","Palīdzība","Jauna cilne","Aizvērt","Iziet","Par","Hub","Atpakaļ","Uz priekšu","Pārlādēt","Sākums","Iet","Meklēt vai adrese","Atjaunot sesiju?","Iestatījumi","Motīvs","Fons","Valoda"],
"et": ["Fail","Abi","Uus kaart","Sulge","Välju","Teave","Hub","Tagasi","Edasi","Laadi uuesti","Kodu","Mine","Otsi või aadress","Taasta seanss?","Seaded","Teema","Taust","Keel"],
"ka": ["ფაილი","დახმარება","ახალი ჩანართი","დახურვა","გასვლა","შესახებ","Hub","უკან","წინ","განახლება","მთავარი","გადასვლა","ძიება ან მისამართი","სესიის აღდგენა?","პარამეტრები","თემა","ფონი","ენა"],
"hy": ["Ֆայլ","Օգնություն","Նոր ներդիր","Փակել","Ելք","Մասին","Hub","Հետ","Առաջ","Թարմացնել","Գլխավոր","Գնալ","Որոնում կամ հասցե","Վերականգնել սեսիան?","Կարգավորումներ","Թեմա","Պաստառ","Լեզու"],
"az": ["Fayl","Kömək","Yeni tab","Bağla","Çıx","Haqqında","Hub","Geri","İrəli","Yenilə","Ana","Get","Axtarış və ya ünvan","Sessiyanı bərpa et?","Parametrlər","Tema","Divar kağızı","Dil"],
"kk": ["Файл","Көмек","Жаңа қойынды","Жабу","Шығу","Туралы","Hub","Артқа","Алға","Жаңарту","Басты","Өту","Іздеу немесе мекенжай","Сеансты қалпына келтіру?","Баптаулар","Тақырып","Тұсқағаз","Тіл"],
"uz": ["Fayl","Yordam","Yangi tab","Yopish","Chiqish","Haqida","Hub","Orqaga","Oldinga","Yangilash","Bosh","O'tish","Qidiruv yoki manzil","Seansni tiklash?","Sozlamalar","Mavzu","Fon","Til"],
"fa": ["پرونده","راهنما","زبانه جدید","بستن","خروج","درباره","Hub","بازگشت","جلو","بازخوانی","خانه","برو","جستجو یا نشانی","بازیابی نشست؟","تنظیمات","پوسته","کاغذدیواری","زبان"],
"bn": ["ফাইল","সাহায্য","নতুন ট্যাব","বন্ধ","প্রস্থান","সম্পর্কে","Hub","পিছনে","সামনে","রিলোড","হোম","যাও","অনুসন্ধান বা ঠিকানা","সেশন পুনরুদ্ধার?","সেটিংস","থিম","ওয়ালপেপার","ভাষা"],
"ta": ["கோப்பு","உதவி","புதிய தாவல்","மூடு","வெளியேறு","பற்றி","Hub","பின்","முன்","ஏற்று","முகப்பு","செல்","தேடல் அல்லது முகவரி","அமர்வை மீட்டமை?","அமைப்புகள்","தீம்","வால்பேப்பர்","மொழி"],
"sw": ["Faili","Usaidizi","Kichupo kipya","Funga","Toka","Kuhusu","Hub","Rudi","Mbele","Onyesha upya","Nyumbani","Nenda","Tafuta au anwani","Rejesha kikao?","Mipangilio","Mandhari","Wallpaper","Lugha"],
}

LANG_NAMES = {
"en":"English","ru":"Русский","uk":"Українська","de":"Deutsch","fr":"Français","es":"Español",
"it":"Italiano","pt":"Português","pl":"Polski","tr":"Türkçe","ar":"العربية","zh":"中文","ja":"日本語",
"ko":"한국어","hi":"हिन्दी","nl":"Nederlands","sv":"Svenska","cs":"Čeština","ro":"Română","el":"Ελληνικά",
"he":"עברית","vi":"Tiếng Việt","th":"ไทย","id":"Indonesia","ms":"Melayu","fi":"Suomi","da":"Dansk",
"no":"Norsk","hu":"Magyar","sk":"Slovenčina","bg":"Български","sr":"Српски","hr":"Hrvatski","lt":"Lietuvių",
"lv":"Latviešu","et":"Eesti","ka":"ქართული","hy":"Հայերեն","az":"Azərbaycan","kk":"Қазақ","uz":"Oʻzbek",
"fa":"فارسی","bn":"বাংলা","ta":"தமிழ்","sw":"Kiswahili",
}

def t(lang: str, key: str) -> str:
    rows = _RAW.get(lang) or _RAW["en"]
    try:
        i = _KEYS.index(key)
        return rows[i]
    except Exception:
        return key

def languages() -> list[tuple[str, str]]:
    return sorted(LANG_NAMES.items(), key=lambda x: x[1].lower())
