from __future__ import annotations
from typing import Any
STR = {
    "en": {"app": "Nyvex Browser", "home": "Home"},
    "ru": {"app": "Nyvex Browser", "home": "Домой"},
}
class I18n:
    def __init__(self, lang: str = "ru") -> None:
        self.lang = lang if lang in STR else "en"
    def t(self, key: str) -> str:
        return STR.get(self.lang, STR["en"]).get(key, key)
    def status(self) -> dict[str, Any]:
        return {"module": "I18n", "ready": True, "lang": self.lang}
