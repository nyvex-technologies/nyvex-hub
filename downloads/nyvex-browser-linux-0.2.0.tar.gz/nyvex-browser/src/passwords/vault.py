from __future__ import annotations
from typing import Any

class PasswordVault:
    """24 — только API; секреты → keyring/Gecko позже."""
    def __init__(self) -> None:
        self._items: list[dict[str, str]] = []  # никогда не логировать password

    def save(self, origin: str, username: str, password: str) -> None:
        self._items = [i for i in self._items if not (i["origin"] == origin and i["username"] == username)]
        self._items.append({"origin": origin, "username": username, "password": password})

    def find(self, origin: str) -> list[dict[str, str]]:
        return [{"origin": i["origin"], "username": i["username"]} for i in self._items if i["origin"] == origin]

    def status(self) -> dict[str, Any]:
        return {"module": "PasswordVault", "ready": True, "count": len(self._items)}
