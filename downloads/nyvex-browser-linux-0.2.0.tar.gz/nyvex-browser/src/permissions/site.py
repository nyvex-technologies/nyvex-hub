from __future__ import annotations
from typing import Any

class SitePermissions:
    """21 — camera/mic/location…"""
    def __init__(self) -> None:
        self._data: dict[str, dict[str, str]] = {}

    def set(self, origin: str, feature: str, value: str) -> None:
        assert value in ("allow", "ask", "block")
        self._data.setdefault(origin, {})[feature] = value

    def get(self, origin: str, feature: str) -> str:
        return self._data.get(origin, {}).get(feature, "ask")

    def status(self) -> dict[str, Any]:
        return {"module": "SitePermissions", "ready": True, "sites": len(self._data)}
