from __future__ import annotations
import json, time, uuid
from pathlib import Path
from typing import Any

class BookmarkStore:
    """Пункт 17 — закладки."""
    def __init__(self, profile: Path | None = None):
        self.path = (Path(profile) if profile else Path.home() / ".local/share/nyvex-browser/Default") / "bookmarks.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.root: dict[str, Any] = {"type": "folder", "id": "root", "title": "Bookmarks", "children": []}
        self.load()

    def load(self) -> None:
        if self.path.is_file():
            self.root = json.loads(self.path.read_text(encoding="utf-8"))
        else:
            self.save()

    def save(self) -> None:
        self.path.write_text(json.dumps(self.root, ensure_ascii=False, indent=2), encoding="utf-8")

    def add(self, url: str, title: str = "", folder_id: str = "root") -> dict:
        item = {"type": "bookmark", "id": uuid.uuid4().hex[:12], "url": url, "title": title or url, "ts": int(time.time())}
        folder = self._find(self.root, folder_id) or self.root
        folder.setdefault("children", []).append(item)
        self.save()
        return item

    def _find(self, node: dict, nid: str) -> dict | None:
        if node.get("id") == nid:
            return node
        for ch in node.get("children", []):
            if ch.get("type") == "folder":
                found = self._find(ch, nid)
                if found: return found
        return None

    def remove(self, item_id: str) -> bool:
        def walk(node: dict) -> bool:
            kids = node.get("children", [])
            for i, ch in enumerate(kids):
                if ch.get("id") == item_id:
                    kids.pop(i)
                    return True
                if ch.get("type") == "folder" and walk(ch):
                    return True
            return False
        ok = walk(self.root)
        if ok: self.save()
        return ok

    def list_flat(self) -> list[dict]:
        out: list[dict] = []
        def walk(node: dict):
            for ch in node.get("children", []):
                if ch.get("type") == "bookmark":
                    out.append(ch)
                elif ch.get("type") == "folder":
                    walk(ch)
        walk(self.root)
        return out
