from __future__ import annotations
from typing import Any
class DevToolsHost:
    def status(self) -> dict[str, Any]:
        return {"module": "DevToolsHost", "ready": False}
