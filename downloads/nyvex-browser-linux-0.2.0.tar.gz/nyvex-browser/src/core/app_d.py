"""Связка навигации + history/bookmarks (часть D)."""
from __future__ import annotations
from pathlib import Path
from navigation.address import normalize_input
from history.store import HistoryStore
from bookmarks.store import BookmarkStore
from downloads.manager import DownloadManager
from internal_pages.registry import is_internal, resolve, render_stub
from browser.engine import Engine

class BrowseService:
    def __init__(self, profile: Path | None = None):
        self.profile = profile or Path.home() / ".local/share/nyvex-browser/Default"
        self.history = HistoryStore(self.profile)
        self.bookmarks = BookmarkStore(self.profile)
        self.downloads = DownloadManager()
        self.engine = Engine()

    def go(self, text: str) -> str:
        url = normalize_input(text)
        if is_internal(url):
            page = resolve(url) or "unknown"
            html = render_stub(page)
            self.engine.load(url)
            print(f"[internal] {page} ({len(html)} bytes)")
            return url
        self.engine.load(url)
        self.history.add(url, title=url)
        return url
