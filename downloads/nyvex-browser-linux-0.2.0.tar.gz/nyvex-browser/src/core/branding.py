"""Официальные данные продукта Nyvex Browser."""
from __future__ import annotations

APP_NAME = "Nyvex Browser"
APP_NAME_SHORT = "Nyvex"
APP_ID = "technologies.nyvex.browser"
VERSION = "0.1.0"
VERSION_LABEL = "0.1.0-dev"
CHANNEL = "Developer"

VENDOR = "Nyvex Technologies"
CREATOR = "Nyvex · Official Black Fox"
COPYRIGHT = "© 2026 Nyvex Technologies"
SUPPORT_EMAIL = "nyvex.technologies@gmail.com"
WEBSITE = "https://nyvex.technologies"  # заглушка / позже свой домен

ENGINE_NAME = "WebKit"
ENGINE_DETAIL = "WebKit2 (GTK)"
ENGINE_NOTE = "Целевой движок по плану: Gecko + SpiderMonkey"

USER_AGENT = (
    f"Mozilla/5.0 (X11; Linux x86_64) "
    f"AppleWebKit/605.1.15 (KHTML, like Gecko) "
    f"NyvexBrowser/{VERSION} Safari/605.1.15"
)

ABOUT_TEXT = f"""{APP_NAME}
Версия {VERSION_LABEL} ({CHANNEL})

{VENDOR}
Создатель: {CREATOR}
{COPYRIGHT}

Движок отображения: {ENGINE_DETAIL}
{ENGINE_NOTE}

Почта: {SUPPORT_EMAIL}

Отдельный продукт экосистемы Nyvex
(Hub · Chat · Universe). Не связан с Mozilla Firefox,
Google Chrome и другими сторонними браузерами.
"""

def about_html() -> str:
    return f"""<!DOCTYPE html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>О {APP_NAME}</title>
<style>
body{{margin:0;font-family:system-ui,sans-serif;background:#1c1b22;color:#fbfbfe;
padding:32px;line-height:1.5}}
h1{{font-size:28px;margin:0 0 8px;color:#a78bfa}}
.muted{{color:#9a96a8}}
.card{{background:#2b2a33;border-radius:12px;padding:16px 18px;margin:16px 0}}
table{{width:100%;border-collapse:collapse}}
td{{padding:6px 8px;border-bottom:1px solid #3a3942}}
td:first-child{{color:#9a96a8;width:42%}}
</style></head><body>
<h1>{APP_NAME}</h1>
<p class="muted">{VERSION_LABEL} · {CHANNEL}</p>
<div class="card">
<table>
<tr><td>Разработчик</td><td>{VENDOR}</td></tr>
<tr><td>Создатель</td><td>{CREATOR}</td></tr>
<tr><td>Движок</td><td>{ENGINE_DETAIL}</td></tr>
<tr><td>Поиск по умолчанию</td><td>DuckDuckGo</td></tr>
<tr><td>Платформа</td><td>Linux (GTK)</td></tr>
<tr><td>Почта</td><td>{SUPPORT_EMAIL}</td></tr>
</table>
</div>
<p class="muted">{COPYRIGHT}<br>
Собственный браузер Nyvex Technologies. Не является модификацией Firefox или Chrome.</p>
</body></html>"""
