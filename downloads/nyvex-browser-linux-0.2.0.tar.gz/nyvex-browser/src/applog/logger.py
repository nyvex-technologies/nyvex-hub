from __future__ import annotations
from typing import Any
class AppLogger:
    def __init__(self, level: str = "INFO") -> None:
        self.level = level
    def log(self, level: str, msg: str) -> None:
        print(f"[{level}] {msg}")
    def status(self) -> dict[str, Any]:
        return {"module": "AppLogger", "ready": True, "level": self.level}
