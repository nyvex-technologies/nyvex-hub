from __future__ import annotations
from urllib.parse import quote_plus
from typing import Any

ENGINES = {
    "duckduckgo": {"name": "DuckDuckGo", "url": "https://duckduckgo.com/?q={query}", "keyword": "d"},
    "google": {"name": "Google", "url": "https://www.google.com/search?q={query}", "keyword": "g"},
    "bing": {"name": "Bing", "url": "https://www.bing.com/search?q={query}", "keyword": "b"},
    "brave": {"name": "Brave", "url": "https://search.brave.com/search?q={query}", "keyword": "br"},
}
DEFAULT_ENGINE = "duckduckgo"

class SearchEngines:
    def __init__(self, default: str = DEFAULT_ENGINE) -> None:
        self.default = default if default in ENGINES else DEFAULT_ENGINE
    def build(self, query: str, engine_id: str | None = None) -> str:
        eid = engine_id or self.default
        return ENGINES.get(eid, ENGINES[DEFAULT_ENGINE])["url"].format(query=quote_plus(query))
    def status(self) -> dict[str, Any]:
        return {"module": "SearchEngines", "ready": True, "default": self.default}
