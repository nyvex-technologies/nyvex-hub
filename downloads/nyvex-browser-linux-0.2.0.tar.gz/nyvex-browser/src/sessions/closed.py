from __future__ import annotations
from collections import deque
from typing import Any

class ClosedTabs:
    def __init__(self, limit: int = 25):
        self._items: deque[dict[str, Any]] = deque(maxlen=limit)

    def push(self, tab: dict[str, Any]) -> None:
        self._items.appendleft(dict(tab))

    def pop(self) -> dict[str, Any] | None:
        return self._items.popleft() if self._items else None

    def list(self) -> list[dict[str, Any]]:
        return list(self._items)
