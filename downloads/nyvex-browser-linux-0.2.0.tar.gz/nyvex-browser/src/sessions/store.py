from __future__ import annotations
import json, threading, time
from copy import deepcopy
from pathlib import Path
from typing import Any

DEFAULT_SESSION = {
    "version": 1,
    "windows": [{"tabs": [{"url": "nyvex://home", "title": "Home", "pinned": False}], "active_tab": 0}],
    "updated_at": 0,
}

class SessionStore:
    def __init__(self, profile_dir: Path, debounce_sec: float = 0.4):
        self.profile_dir = Path(profile_dir)
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.profile_dir / "session.json"
        self.backup = self.profile_dir / "session-backup.json"
        self.dirty_flag = self.profile_dir / "session.dirty"
        self._data = deepcopy(DEFAULT_SESSION)
        self._debounce = debounce_sec
        self._timer = None
        self._lock = threading.Lock()

    def load(self) -> dict[str, Any]:
        if self.path.is_file():
            self._data = json.loads(self.path.read_text(encoding="utf-8"))
        else:
            self._data = deepcopy(DEFAULT_SESSION)
        return deepcopy(self._data)

    def get(self) -> dict[str, Any]:
        with self._lock:
            return deepcopy(self._data)

    def mark_dirty_start(self) -> None:
        """Сессия открыта — при краше флаг останется."""
        self.dirty_flag.write_text("1", encoding="utf-8")

    def mark_clean_shutdown(self) -> None:
        self.save_now()
        if self.dirty_flag.exists():
            self.dirty_flag.unlink()

    def crashed(self) -> bool:
        """Некорректное завершение: флаг dirty остался с прошлого запуска."""
        return self.dirty_flag.exists()

    def has_session_file(self) -> bool:
        return self.path.is_file()

    def schedule_save(self) -> None:
        with self._lock:
            if self._timer:
                self._timer.cancel()
            self._timer = threading.Timer(self._debounce, self.save_now)
            self._timer.daemon = True
            self._timer.start()

    def save_now(self) -> None:
        with self._lock:
            self._data["updated_at"] = int(time.time())
            text = json.dumps(self._data, ensure_ascii=False, indent=2)
            if self.path.is_file():
                self.backup.write_text(self.path.read_text(encoding="utf-8"), encoding="utf-8")
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(text, encoding="utf-8")
            tmp.replace(self.path)

    def set_tabs(self, window_index: int, tabs: list[dict], active: int) -> None:
        with self._lock:
            while len(self._data["windows"]) <= window_index:
                self._data["windows"].append({"tabs": [], "active_tab": 0})
            self._data["windows"][window_index]["tabs"] = tabs
            self._data["windows"][window_index]["active_tab"] = active
        self.schedule_save()
