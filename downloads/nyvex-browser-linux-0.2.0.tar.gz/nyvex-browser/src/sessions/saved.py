from __future__ import annotations
import json, time
from pathlib import Path
from typing import Any

class SavedSessions:
    def __init__(self, profile: Path):
        self.dir = Path(profile) / "saved-sessions"
        self.dir.mkdir(parents=True, exist_ok=True)

    def list(self) -> list[dict[str, Any]]:
        out = []
        for p in sorted(self.dir.glob("*.json")):
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                out.append({"id": p.stem, "name": data.get("name", p.stem), "path": str(p)})
            except Exception:
                pass
        return out

    def save(self, name: str, session: dict[str, Any]) -> Path:
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in name)[:64]
        path = self.dir / f"{safe}.json"
        path.write_text(json.dumps({"name": name, "saved_at": int(time.time()), "session": session}, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def load(self, session_id: str) -> dict[str, Any] | None:
        path = self.dir / f"{session_id}.json"
        if not path.is_file(): return None
        return json.loads(path.read_text(encoding="utf-8"))

    def delete(self, session_id: str) -> bool:
        path = self.dir / f"{session_id}.json"
        if path.is_file():
            path.unlink(); return True
        return False
