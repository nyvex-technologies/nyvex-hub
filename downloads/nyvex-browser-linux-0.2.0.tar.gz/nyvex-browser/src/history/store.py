from __future__ import annotations
import json, time
from pathlib import Path
from typing import Any

class HistoryStore:
    """Пункт 16 — история."""
    def __init__(self, profile: Path | None = None):
        self.path = (Path(profile) if profile else Path.home() / ".local/share/nyvex-browser/Default") / "history.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._items: list[dict[str, Any]] = []
        self.load()

    def load(self) -> None:
        if self.path.is_file():
            self._items = json.loads(self.path.read_text(encoding="utf-8"))
        else:
            self._items = []

    def save(self) -> None:
        self.path.write_text(json.dumps(self._items[-5000:], ensure_ascii=False, indent=2), encoding="utf-8")

    def add(self, url: str, title: str = "") -> None:
        if url.startswith("nyvex://"):
            return
        now = int(time.time())
        for it in self._items:
            if it["url"] == url:
                it["title"] = title or it.get("title") or url
                it["ts"] = now
                it["visits"] = int(it.get("visits", 1)) + 1
                self.save()
                return
        self._items.append({"url": url, "title": title or url, "ts": now, "visits": 1})
        self.save()

    def search(self, q: str) -> list[dict]:
        q = q.lower().strip()
        if not q:
            return list(reversed(self._items[-100:]))
        return [i for i in reversed(self._items) if q in i["url"].lower() or q in i.get("title", "").lower()][:100]

    def delete_url(self, url: str) -> None:
        self._items = [i for i in self._items if i["url"] != url]
        self.save()

    def clear(self) -> None:
        self._items = []
        self.save()
