"""Подсказки как в Firefox Awesome Bar: история + закладки + поиск."""
from __future__ import annotations
from typing import Any
from navigation.address import normalize_input, looks_like_url
from search.engines import SearchEngines

class Omnibox:
    def __init__(
        self,
        history_items: list[dict] | None = None,
        bookmark_items: list[dict] | None = None,
        engine_id: str = "duckduckgo",
    ) -> None:
        self.history = history_items or []
        self.bookmarks = bookmark_items or []
        self.engines = SearchEngines(engine_id)

    def suggest(self, text: str, limit: int = 8) -> list[dict[str, Any]]:
        q = text.strip().lower()
        out: list[dict[str, Any]] = []
        if not q:
            return out

        # закладки
        for b in self.bookmarks:
            url = b.get("url", "")
            title = b.get("title", "")
            if q in url.lower() or q in title.lower():
                out.append({"type": "bookmark", "title": title or url, "url": url})
            if len(out) >= limit:
                return out

        # история
        for h in self.history:
            url = h.get("url", "")
            title = h.get("title", "")
            if q in url.lower() or q in title.lower():
                out.append({"type": "history", "title": title or url, "url": url})
            if len(out) >= limit:
                return out

        # поисковая подсказка
        if not looks_like_url(text.strip()):
            out.append({
                "type": "search",
                "title": f"Искать «{text.strip()}» в {self.engines.list()[0]['name'] if False else self.engines.default}",
                "url": self.engines.build(text.strip()),
            })
        else:
            url = normalize_input(text)
            out.insert(0, {"type": "url", "title": url, "url": url})

        return out[:limit]

    def resolve(self, text: str) -> str:
        return normalize_input(text, engine_id=self.engines.default)
