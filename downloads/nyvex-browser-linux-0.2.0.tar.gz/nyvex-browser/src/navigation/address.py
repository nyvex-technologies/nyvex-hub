from __future__ import annotations
from urllib.parse import quote_plus
from search.engines import ENGINES, DEFAULT_ENGINE, SearchEngines

def looks_like_url(text: str) -> bool:
    t = text.strip()
    if not t: return False
    if " " in t and "://" not in t: return False
    if t.startswith(("http://", "https://", "nyvex://", "file://", "about:")): return True
    if t.startswith("localhost") or t.startswith("127."): return True
    if "." in t and " " not in t: return True
    return False

def normalize_input(text: str, engine_id: str | None = None) -> str:
    t = text.strip()
    if not t: return "nyvex://newtab"
    if t.startswith("nyvex://"): return t
    engines = SearchEngines(engine_id or DEFAULT_ENGINE)
    parts = t.split(maxsplit=1)
    if len(parts) == 2:
        for eid, meta in ENGINES.items():
            if meta.get("keyword") == parts[0].lower():
                return engines.build(parts[1], eid)
    if looks_like_url(t):
        return t if "://" in t else "https://" + t
    return engines.build(t, engine_id)
