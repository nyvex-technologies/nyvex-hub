"""Пункты 15/34 — nyvex://"""
from __future__ import annotations

PAGES = {
    "nyvex://home": "home",
    "nyvex://settings": "settings",
    "nyvex://history": "history",
    "nyvex://bookmarks": "bookmarks",
    "nyvex://downloads": "downloads",
    "nyvex://sessions": "sessions",
    "nyvex://extensions": "extensions",
    "nyvex://privacy": "privacy",
    "nyvex://profiles": "profiles",
    "nyvex://about": "about",
    "nyvex://version": "version",
}

def is_internal(url: str) -> bool:
    return url.startswith("nyvex://")

def resolve(url: str) -> str | None:
    key = url.split("?", 1)[0].rstrip("/")
    return PAGES.get(key)

def render_stub(page: str) -> str:
    return f"<html><body style='font-family:sans-serif;background:#0b1020;color:#eef'><h1>Nyvex · {page}</h1><p>Internal page scaffold</p></body></html>"
