from __future__ import annotations
from typing import Any

class AutofillStore:
    def __init__(self) -> None:
        self.profiles: list[dict[str, str]] = []

    def status(self) -> dict[str, Any]:
        return {"module": "AutofillStore", "ready": True, "profiles": len(self.profiles)}
