from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from browser.facade import NyvexBrowserApp

def main():
    app = NyvexBrowserApp()
    print("=== Nyvex Browser 0.1.0-dev ===")
    print(app.diagnostics.report())
    print("nav", app.navigate("nyvex://home"))
    print("nav", app.navigate("https://example.com"))
    print("probe", app.engine.gecko.probe_https("https://example.com"))
    print("modules:")
    for m in app.module_matrix():
        print(" ", m)
    app.shutdown()
    print("UI: PYTHONPATH=src python3 -m browser.ui_tk")

if __name__ == "__main__":
    main()
