from __future__ import annotations
import uuid
from typing import Any
from tabs.manager import TabManager

class WindowManager:
    """Пункты 4/12 — окна."""
    def __init__(self) -> None:
        self.windows: list[dict[str, Any]] = []
        self.active = 0
        self.new_window(private=False)

    def new_window(self, private: bool = False) -> dict:
        tm = TabManager()
        tm.new("nyvex://home")
        w = {
            "id": uuid.uuid4().hex[:12],
            "private": private,
            "tabs": tm,
            "x": 0, "y": 0, "width": 1200, "height": 800,
        }
        self.windows.append(w)
        self.active = len(self.windows) - 1
        return w

    def current(self) -> dict:
        return self.windows[self.active]

    def current_tabs(self) -> TabManager:
        return self.current()["tabs"]

    def close_window(self, index: int | None = None) -> None:
        if len(self.windows) <= 1: return
        i = self.active if index is None else index
        self.windows.pop(i)
        self.active = min(i, len(self.windows) - 1)

    def to_session(self) -> dict:
        wins = []
        for w in self.windows:
            tm: TabManager = w["tabs"]
            wins.append({
                "id": w["id"],
                "private": w["private"],
                "tabs": list(tm.tabs),
                "active_tab": tm.active,
                "x": w["x"], "y": w["y"], "width": w["width"], "height": w["height"],
            })
        return {"version": 1, "windows": wins}
