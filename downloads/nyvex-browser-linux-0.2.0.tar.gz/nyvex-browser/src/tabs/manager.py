from __future__ import annotations
import uuid
from typing import Any

def _id() -> str:
    return uuid.uuid4().hex[:12]

class TabManager:
    """Пункт 5 — логика вкладок."""
    def __init__(self) -> None:
        self.tabs: list[dict[str, Any]] = []
        self.active = 0

    def new(self, url: str = "nyvex://home", title: str = "New Tab") -> dict:
        tab = {"id": _id(), "url": url, "title": title, "pinned": False, "muted": False}
        self.tabs.append(tab)
        self.active = len(self.tabs) - 1
        return tab

    def close(self, index: int | None = None) -> dict | None:
        if not self.tabs: return None
        i = self.active if index is None else index
        if i < 0 or i >= len(self.tabs): return None
        closed = self.tabs.pop(i)
        self.active = min(i, max(0, len(self.tabs) - 1))
        return closed

    def select(self, index: int) -> None:
        if 0 <= index < len(self.tabs):
            self.active = index

    def next(self) -> None:
        if self.tabs:
            self.active = (self.active + 1) % len(self.tabs)

    def prev(self) -> None:
        if self.tabs:
            self.active = (self.active - 1) % len(self.tabs)

    def pin(self, index: int | None = None) -> None:
        i = self.active if index is None else index
        if 0 <= i < len(self.tabs):
            self.tabs[i]["pinned"] = not self.tabs[i].get("pinned", False)

    def set_url(self, url: str, index: int | None = None) -> None:
        i = self.active if index is None else index
        if 0 <= i < len(self.tabs):
            self.tabs[i]["url"] = url

    def current(self) -> dict | None:
        if not self.tabs: return None
        return self.tabs[self.active]
