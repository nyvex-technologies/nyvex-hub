from __future__ import annotations
import json
from pathlib import Path
from typing import Any

DEFAULTS = {
    "startup": "home",  # home | restore | pages
    "save_session": True,
    "restore_after_crash": True,
    "search_engine": "duckduckgo",
    "theme": "nyvex-dark",
    "locale": "ru",
}

class SettingsStore:
    def __init__(self, profile: Path | None = None) -> None:
        self.path = (profile or Path.home() / ".local/share/nyvex-browser/Default") / "settings.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data = dict(DEFAULTS)
        if self.path.is_file():
            self.data.update(json.loads(self.path.read_text(encoding="utf-8")))

    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self.data[key] = value
        self.path.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")

    def status(self) -> dict[str, Any]:
        return {"module": "SettingsStore", "ready": True, "data": self.data}
