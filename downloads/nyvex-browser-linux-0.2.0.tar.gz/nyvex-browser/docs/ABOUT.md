# Nyvex Browser 0.2

**Создатель:** Nyvex Technologies · Official Black Fox  
**Почта:** nyvex.technologies@gmail.com  

## Движок
WebKit2 (WebKitGTK) — полноценный движок уровня Safari/GNOME Web.

## Уже есть
- Вкладки, адресная строка, поиск (DuckDuckGo + ключевые слова)
- Сессии и восстановление
- Темы / newtab
- Кнопка / вкладка Nyvex Hub
- Установка в меню Linux (`nyvex-browser`)

## Платформы
- Linux — текущая сборка
- Windows / Android — отдельные клиенты (в разработке)

Не связан с Mozilla Firefox и Google Chrome.
