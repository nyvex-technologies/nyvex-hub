# Nyvex Browser — части
A фундамент · B сессии · C вкладки/окна · D хранилище · E Gecko · F UI · G privacy · H advanced · I reliability · J sync
